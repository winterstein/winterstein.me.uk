
#include "City.h" // class's header file

// Initialise static variables
float City::sGridSquareWidth = 1.0f; // initialise to a safe dummy value.

// The main constructor
City::City(World* world, int width, int height, int streetWidth, int blockWidth) {
   mWorld = world;
   mWidth = width; mHeight = height;
   mStreetWidth = streetWidth; mBlockWidth = blockWidth;
   mGridWidth = width*(streetWidth + blockWidth) + streetWidth;
   mGridHeight = height*(streetWidth + blockWidth) + streetWidth;

   sGridSquareWidth = 2.0f / max(mGridWidth, mGridHeight);
   Locn::setGridSquareWidth(sGridSquareWidth);

   // create block map and radiation maps
   blockMap = new int* [mGridHeight];
   mCitizenRadiation = new int* [mGridHeight];
   mCopRadiation = new int* [mGridHeight];
   mCriminalRadiation = new int* [mGridHeight];
   mLootRadiation = new int* [mGridHeight];
   mCornerMap = new float** [mGridHeight+1];
   for(int i=0; i<mGridHeight; i++) {
      blockMap[i] = new int[mGridWidth];
      mCitizenRadiation[i] = new int [mGridWidth];
      mCopRadiation[i] = new int [mGridWidth];
      mCriminalRadiation[i] = new int [mGridWidth];
      mLootRadiation[i] = new int [mGridWidth];
      mCornerMap[i] = new float* [mGridWidth+1];
      for(int j=0; j<mGridWidth+1; j++) {
         mCornerMap[i][j] = new float [3];
      }
   }
   mCornerMap[mGridHeight] = new float* [mGridWidth+1];
   for(int j=0; j<mGridWidth+1; j++) {
      mCornerMap[mGridHeight][j] = new float [3];
   }
   // start blank
   for(int i=0; i<mGridHeight; i++) {
      for(int j=0; j<mGridWidth; j++) {
         blockMap[i][j] =  0;
         mCitizenRadiation[i][j] = 0;
         mCopRadiation[i][j] = 0;
         mCriminalRadiation[i][j] = 0;
         mLootRadiation[i][j] = 0;
      }
   }

   makeCityMap();

   // Initialise population lists
   mPeople;
}

City::~City() {
   // Delete the maps
   for(int i=0; i<mGridHeight; i++) delete[] blockMap[i];
   delete[] blockMap;
   for(int i=0; i<mGridHeight; i++) delete[] mCitizenRadiation[i];
   delete[] mCitizenRadiation;
   for(int i=0; i<mGridHeight; i++) delete[] mCriminalRadiation[i];
   delete[] mCriminalRadiation;
   for(int i=0; i<mGridHeight; i++) delete[] mCopRadiation[i];
   delete[] mCopRadiation;
   for(int i=0; i<mGridHeight; i++) delete[] mLootRadiation[i];
   delete[] mLootRadiation;
   for(int i=0; i<mGridHeight+1; i++) {
      for(int j=0; j<mGridWidth+1; j++) {
         delete[] mCornerMap[i][j];
      }
   }
   delete[] mCornerMap;   
   // and the people
   mPeople.clear();
   /* mCriminals; // These objects should all be deleted by mPeople.clear()
      mCops;
      Loot* mLoot;
      */

}

// Returns true or false with 50%/50% probability
bool coinToss() {
   float r = 1.0*rand() / RAND_MAX;
   if (r > 0.5) return true;
   else return false;
}

void City::makeCityMap() {
   // The real width of a street
   int sw = 2*mStreetWidth+1;
   // start plain
   for(int i=0; i<mGridHeight; i++) {
      for(int j=0; j<mGridWidth; j++) {
         if (i>=sw && i<mGridHeight-sw
             && j >= sw && j<mGridWidth-sw) blockMap[i][j] =  1;
         else blockMap[i][j] = 0;
      }
   }

   // add random streets
   //  - let these be dead ends some of the time
   int deadEnd;

   // Clip the corners 'cos it looks nicer
   blockMap[sw][sw] = 0;
   blockMap[mGridHeight-sw-1][sw] = 0;
   blockMap[sw][mGridWidth-sw-1] = 0;
   blockMap[mGridHeight-sw-1][mGridWidth-sw-1] = 0;

   // Horizontal starting streets
   int step = (mGridHeight-sw) / mHeight;
   for(int i=1; i<mHeight; i++) {
      if (coinToss()) deadEnd = 1; else deadEnd = 0;
      makeRandomStreet(sw + 2*deadEnd, sw+i*step,1,0);
      if (coinToss()) deadEnd = 1; else deadEnd = 0;
      makeRandomStreet(mGridWidth-sw-1 - 2*deadEnd, sw+i*step,-1,0);
   }
   // Vertical starting streets
   step = (mGridWidth-sw) / mWidth;
   for(int i=1; i<mWidth; i++) {
      if (coinToss()) deadEnd = 1; else deadEnd = 0;
      makeRandomStreet(sw+i*step, sw + 2*deadEnd, 0,1);
      if (coinToss()) deadEnd = 1; else deadEnd = 0;
      makeRandomStreet(sw+i*step, mGridWidth-sw+1 -2*deadEnd, 0,-1);
   }
   // clean up the street sides
   for(int i=0; i<mGridHeight; i++) {
      for(int j=0; j<mGridWidth; j++) {
         if (blockMap[i][j] == -1) blockMap[i][j] = 0;
      }
   }
}

bool City::withinBounds(int gridX, int gridY) {
   if (min(gridX,gridY)<0
         || gridX >= mGridWidth || gridY >= mGridHeight) return false;
   return true;
}

/* Generate a random street
   ASSUME: the city has a border of clear (street) squares.
*/
void City::makeRandomStreet(int x, int y, int dx, int dy) {
   int length = mBlockWidth;
   if (coinToss()) length += mBlockWidth/2;
   else length -= mBlockWidth/2;
   int width = mStreetWidth;
   if (coinToss() && coinToss()) width = width/2;
   int by, bx;
   for(int i=0; i<length; i++) {
      for(int j=-width; j<width+1; j++) {
         by= y+i*dy+j*dx;
         bx= x+i*dx+j*dy;
         if (!withinBounds(bx,by)) {
            #ifdef DEBUG
            *World::fileOut << i << "ERROR: street over-running in makeRandomStreet\n"<< endl;
            #endif // DEBUG
            return;
         }
         if (j==0) {
            if (blockMap[by][bx]==0) return; // Street finished
            blockMap[by][bx] = 0;
         } else {
            if (blockMap[by][bx] != 0) blockMap[by][bx] = -1; // temporarily set the street sides to -1
         }
      }
   }
   x += length*dx; y+= length*dy;
   if (coinToss()) makeRandomStreet(x, y, dx, dy); // continue
   // change direction
   int temp = dx;
   if (coinToss()) {
      dx = -dy; dy=-temp;
   } else {
      dx=dy; dy=temp;
   }
   makeRandomStreet(x-dx, y-dy, dx, dy);
}

/* The copy constructor
ASSUME: We only have one city, so this is not needed.
*/
City::City(const City& city) {
  LOUT("ERROR: Copy constructor called for City! This should not happen. Abort! Abort! Aargh!");
   throw "Copy constructor called for City!";
}

/*
   Note: This procedure is inefficient (~400 polygons where ~10 + a shader would do).
   On the other hand, it runs fast enough so who cares?
*/
void City::draw(void) {
   // make the radiation pulsate
   float pulse = 0.7 + 0.3*cos(2*mWorld->getTime());

   for(int h=0; h<mGridHeight+1; h++) {
      for(int w=0; w<mGridWidth+1; w++) {
        float avg[3] = {0, 0, 0};
        int neighbours = 0;
        for(int dy=0; dy<2; dy++) {
          for(int dx=0; dx<2; dx++) {
            if (!withinBounds(w+dx, h+dy)) continue;
            neighbours++;
            float criminal = pulse*0.2*mCriminalRadiation[h][w] / Criminal::sRange;
            float cop = pulse*0.2*mCopRadiation[h][w] / Cop::sRange;
            float pleb = pulse*0.15*mCitizenRadiation[h][w] / (2*Person::sRange);
            avg[0] += criminal;
            avg[1] += pleb;
            avg[2] += cop;
          }
        }
        for(int c=0; c<3; c++) {
           if (neighbours) mCornerMap[h][w][c] = avg[c] / neighbours;
           else mCornerMap[h][w][c] = 0;
        }
      }
   }
   float halfSquare = sGridSquareWidth / 2.0;

   // draw wall squares
	// set wall colour - kind of granite
   glColor3f(0.3, 0.3, 0.4);
   for(int w=0; w<mGridWidth; w++) {
      for(int h=0; h<mGridHeight; h++) {
   	  glBegin(GL_POLYGON);
   		// Specify vertices: top-left, bottom-left, bottom-right, top-right
   		if (!blockMap[h][w]) continue; // ignore street squares
         for(int dx=-1; dx<2; dx+=2) {
            for(int dy=dx; abs(dy)<2; dy -= 2*dx) {
            // ASSUME: This won't overrun the array bounds because of the clear border round the city
               if (!blockMap[h+dy][w] && !blockMap[h][w+dx] && !blockMap[h+dy][w+dx]) {
               // Corner Wall - chip it off
                  glVertex2f(-1 + (w+0.5)*sGridSquareWidth +(dx-dy)*halfSquare/2,
                             -1 + (h+0.5)*sGridSquareWidth +(dx+dy)*halfSquare/2);

                  glVertex2f(-1 + (w+0.5)*sGridSquareWidth +dx*halfSquare/ROOT_TWO,
                             -1 + (h+0.5)*sGridSquareWidth +dy*halfSquare/ROOT_TWO);

                  glVertex2f(-1 + (w+0.5)*sGridSquareWidth +(dy+dx)*halfSquare/2,
                             -1 + (h+0.5)*sGridSquareWidth +(dy-dx)*halfSquare/2);
               } else {
               // Normal wall
                  glVertex2f(-1 + (w+0.5)*sGridSquareWidth +dx*halfSquare, -1 + (h+0.5)*sGridSquareWidth+dy*halfSquare);
               }
            }
         }
      	glEnd();
      }
   }

   // Streets
   for(int w=0; w<mGridWidth; w++) {
      for(int h=0; h<mGridHeight; h++) {
         if (blockMap[h][w]) continue; // ignore wall squares
    	   glBegin(GL_POLYGON); // Specify which primitive type is to be drawn
   		// Specify vertices: top-left, bottom-left, bottom-right, top-right
         // Street square
         glColor3f(mCornerMap[h][w][0],mCornerMap[h][w][1],mCornerMap[h][w][2]);
         //criminal, pleb-cop-criminal, cop);
   	  	glVertex2f(-1 + w*sGridSquareWidth, -1 + h*sGridSquareWidth);
         glColor3f(mCornerMap[h+1][w][0],mCornerMap[h+1][w][1],mCornerMap[h+1][w][2]);
   		glVertex2f(-1 + w*sGridSquareWidth, -1 + (h+1)*sGridSquareWidth);
         glColor3f(mCornerMap[h+1][w+1][0],mCornerMap[h+1][w+1][1],mCornerMap[h+1][w+1][2]);
   		glVertex2f(-1 + (w+1)*sGridSquareWidth, -1 + (h+1)*sGridSquareWidth);
         glColor3f(mCornerMap[h][w+1][0],mCornerMap[h][w+1][1],mCornerMap[h][w+1][2]);
   		glVertex2f(-1 + (w+1)*sGridSquareWidth, -1 + h*sGridSquareWidth);
      	glEnd();
      }
   }

   // Now draw the people - those that are visible
   for(int i=0; i<mPeople.size(); i++) {
      Person* p = mPeople[i];
      // Don't draw invisible people - except for players who are always drawn
      if (!p->mVisible || !p->mPosn) continue;
      p->draw();
   }
   Player::player1->drawScore();   
   if (Player::player2) Player::player2->drawScore();   
}

void City::move(void) {
   #ifdef DEBUG
   *World::fileOut << "---------moving city\n";
   #endif // DEBUG
    // move the people
   for(int i=0; i<mPeople.size(); i++) {
      mPeople[i]->move();
   }
   #ifdef DEBUG
   *World::fileOut << "---------city moved"<<endl;
   #endif // DEBUG
}


bool City::checkStreetLocn(Locn& locn) {
   float y =locn.getY(), x=locn.getX();
   float radius = Person::radius;
   // Check city bounds (-1,1)
   if (max(abs(x),abs(y)) + radius > 1) {
      return false;
   }
   // check block
   int gy=locn.getGridY(), gx=locn.getGridX();
   if (blockMap[gy][gx]) return false;
   // Check neighbouring blocks to see if this locn could overlap
   Locn* gsc = locn.getGridSquareCentre();
   float offX = x - gsc->getX(), offY = y - gsc->getY();
   float halfSquare = sGridSquareWidth/2;
   int dx=0, dy=0;
   if (halfSquare < (abs(offX)+radius)) {
      if (offX<0) dx=-1; else dx=1;
      if (blockMap[gy][gx+dx]) return false;
   }
   if (halfSquare < abs(offY)+radius) {
      if (offY<0) dy=-1; else dy=1;
      if (blockMap[gy+dy][gx]) return false;
   }
/*   if (dx && dy) { // chipped corners means this won't cause an overlap
      if (blockMap[gy+dy][gx+dx]) return false;
   }*/
   return true;
}

bool City::checkCollision(Person* person, bool generateCollisionEvents) {
   if (!person->mVisible) return true; // no collisions with the invisible
   // Check for collisions
   // Note: This is inefficient - O(n) where we could get constant time by keeping
   // an index of grid locations to units. It is also called n times, rather than once.
   for(int i=0; i<mPeople.size(); i++) {
      Person* bob = mPeople[i];
      if (bob==person) continue; // don't test for self-collision
      if (!bob->mVisible) return true; // no collisions with the invisible
      if (bob->overlap(*person)) {
         if (generateCollisionEvents) {
            // Is this collision already known about?
            if (Event::testEquivalence(&typeid(EventCollision),mWorld,person,bob)
                  || Event::testEquivalence(&typeid(EventCollision),mWorld,bob,person)) return false;
            Event* dummy = new EventCollision(mWorld,bob,person);
         }
         return false; // Not a valid location due to the collision
      }
   }
   return true;
}

Locn* City::randomStreetLocn(Person* person) {
   LOUT("Creating a random location");
   bool doneFlag = false;
   Locn* randomLocn = NULL;
   // ASSUME: There are lots of suitable locns, so we won't get stuck here for long.
   while(!doneFlag) {
      float x = -1 + 2*rand()/(RAND_MAX+1.0);
      float y = -1 + 2*rand()/(RAND_MAX+1.0);
      randomLocn = new Locn(x,y);
      if (checkStreetLocn(*randomLocn)) {
         if (!person || checkCollision(person, false)) doneFlag = true;
      } else delete randomLocn;
   }
   if (person) person->mPosn = randomLocn;
   return randomLocn;
}


void City::radiate() {
   radiate(mCitizenRadiation,ADDITIVE, EXPONENTIAL);
   radiate(mCopRadiation, SHORTEST_PATH, LINEAR);
   radiate(mCriminalRadiation, SHORTEST_PATH, EXPONENTIAL);
   radiate(mLootRadiation, SHORTEST_PATH, EXPONENTIAL);
   // Now the people - emit some fresh radiation
   for(int i=0; i<mPeople.size(); i++) {
      mPeople[i]->radiate();
   }
}

int City::radiate(int** map, int type, int decayType) {
   int total = 0;
   // Create temporary map
   // create block map and radiation maps
   int** tempMap = new int* [mGridHeight];
   for(int i=0; i<mGridHeight; i++) {
      tempMap[i] = new int [mGridWidth];
   }
   int newRad, neighbours;
   for(int y=0; y<mGridHeight; y++) {
      for(int x=0; x<mGridWidth; x++) {
         // Check this is a street square
         if (blockMap[y][x] != 0) {
            tempMap[y][x] = 0; // initialise temp map
            continue;
         }
         newRad = 0;
         neighbours = 0; // count the neighbouring street squares
         for(int dx=-1; dx<2; dx++) {
            for(int dy=-1; dy<2; dy++) {
               // check we are within the map
               if (!withinBounds(x+dx,y+dy)) continue;
               // check that this is a street square
               if (blockMap[y+dy][x+dx] != 0) continue;
               neighbours++;
               switch(type) {
                  case SHORTEST_PATH:
                  /* Propagate radiation so as to find the shortest path to an emitter.
                     This is just a breadth-first search, spread over multiple turns.
                  */
                    if (map[y+dy][x+dx] > newRad) newRad = map[y+dy][x+dx];
                    break;
                  case ADDITIVE:
                  /* Propagate radiation so as to handle cumulative effects.
                     This is a more interesting function (though less predictable).
                  */
                    newRad += map[y+dy][x+dx];
                    break;
                  default:
                    LOUT("ERROR: unrecognised propagation fn type");
               } // switch
            }
         }
         switch(decayType) {
           case LINEAR: // Gives more long ranged effects
              newRad--;
              break;
           case EXPONENTIAL: // Gives localised effects
              newRad *= 0.9;
              break;
           default:
             LOUT("ERROR: unrecognised propagation fn type");
         }
         switch(type) {
            case SHORTEST_PATH:
              tempMap[y][x] = max(0, newRad);
              break;
            case ADDITIVE:
              if (newRad && neighbours) tempMap[y][x] = max(0, newRad / neighbours);
              else tempMap[y][x] = 0;
              break;
            default:
              LOUT("ERROR: unrecognised propagation fn type");
         } // switch
      } // outer loop
   }
   for(int y=0; y<mGridHeight; y++) {
      for(int x=0; x<mGridWidth; x++) {
         map[y][x] = tempMap[y][x];
         total += tempMap[y][x];
      }
      delete [] tempMap[y]; // free up the arrays as we go
   }
   delete [] tempMap;
   return total;
}


void City::getRadiation(int local[3][3], int gx, int gy, int type) {
   int** map;
   switch (type) {
      case PERSON: map = mCitizenRadiation; break;
      case COP: map = mCopRadiation; break;
      case CRIMINAL: map = mCriminalRadiation; break;
      case LOOT: map = mLootRadiation; break;
      default:
         LOUT("Error: unrecognised radiation type.");
         throw "Error: unrecognised radiation type.";
   }
   for(int dy=-1; dy<2; dy++) {
      for(int dx=-1; dx<2; dx++) {
         // protect against array bounds violation
         if (!withinBounds(gx+dx,gy+dy) || blockMap[gy+dy][gx+dx]) {
            local[dy+1][dx+1] = MAX_RADIATION;
         } else local[dy+1][dx+1] = map[gy+dy][gx+dx];
      }
   }
}


bool City::isBlock(int gx, int gy) {
  #ifdef DEBUG
  if (!withinBounds(gx,gy)) LOUT("ERROR: out of bounds blockMap request");
  #endif
  if (blockMap[gy][gx]) return true;
  else return false;
}

void City::getBlockMap(int local[3][3], int gx, int gy) {
   for(int dy=-1; dy<2; dy++) {
      for(int dx=-1; dx<2; dx++) {
         // protect against array bounds violation
         if (!withinBounds(gx+dx,gy+dy)) local[dy+1][dx+1] = 1;
         else local[dy+1][dx+1] = blockMap[gy+dy][gx+dx];
      }
   }
}
