/* File: Cop.cpp

*/

#include "Cop.h" // class's header file

// Initialise static variables
int Cop::sRange = 50;


// class constructor
Cop::Cop(World* world) : Person::Person(world) {
   mColour[0] = 0.0f;   mColour[1] = 0.0f;   mColour[2] = 1.0f;
   // A bit more agile than a citizen 
   mAGILITY = 0.1;
   // register as a cop
   mCity->mCops.push_back(this);
}

// class destructor
Cop::~Cop()
{
	// insert your code here
}

void Cop::move(void) {
   if (!mMove) return;
   if (!mAlive) return; // dead people don't move.
   changeDirection();
   // Get the local radiation maps
   int gx = mPosn->getGridX();
   int gy = mPosn->getGridY();
   int localPersonRadiation[3][3];
   int localCriminalRadiation[3][3];
   int localCopRadiation[3][3];
   mCity->getRadiation(localPersonRadiation,gx,gy,City::PERSON);
   mCity->getRadiation(localCopRadiation,gx,gy,City::COP);
   mCity->getRadiation(localCriminalRadiation,gx,gy,City::CRIMINAL);

   /* Combine the maps
      Cops: chase criminals
            avoid each other
            move randomly
      In roughly that order
   */
   int localRadiation[3][3];
   for(int i=0; i<3; i++) {
      for(int j=0; j<3; j++) {
         localRadiation[i][j] = localPersonRadiation[i][j]
                                 - 15 * localCriminalRadiation[i][j]
                                 + 75 * localCopRadiation[i][j]
                                 - (abs(i-1-targetdy)+abs(j-1-targetdx));
      }
   }
   radiationMove(localRadiation);
   tryMove();
   return;
}

void Cop::radiate(void) {
   if (!mVisible || !mPosn) return; // inivisible people don't affect the radiation maps
   Person::radiate();    // Cops are people too
   mCity->mCopRadiation[mPosn->getGridY()][mPosn->getGridX()] = Cop::sRange;
}
