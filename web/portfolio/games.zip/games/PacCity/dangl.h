/* File: dangl.h

Contains some Open GL routines.
In time this may grow into a library of Open Gl routines...

*/
#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <math.h>
#include <stdio.h>
#include "tga.h" // CodeHead's bitmap loader
//#include "TextureLoader.h"
//#include <SDL/SDL.h> // We include SDL just for its image loading routines

void renderBitmapString(
		float x,
		float y,
		float z,
		char *string);

void renderStrokeString(
		float x,
		float y,
		float z,
		char *string);

GLuint LoadTexture(char *TexName);
GLuint LoadTextureRAW( const char * filename, int wrap );
//GLuint loadImage(char* fileName);
