/* File: Criminal.cpp

   The player-controlled criminal.
*/

#ifndef PLAYER_H

class Player; // Protect against loops in the include chain: forward declare

#include "Criminal.h" // inheriting class's header file
#ifdef PERSON_DEFINED // if person was defined, then Criminal will be too
#define PLAYER_H

#include "World.h"
#include "Loot.h"
#include <gl/glut.h> // key constants
#include "dangl.h"
#include <iostream>
#include <string>
#include <sstream>

// Key constants for the arrow keys
const int UP1 = GLUT_KEY_UP;
#define DOWN1 GLUT_KEY_DOWN
#define LEFT1 GLUT_KEY_LEFT
#define RIGHT1 GLUT_KEY_RIGHT

const int UP2 = 'q';
#define DOWN2 'a'
#define LEFT2 'z'
#define RIGHT2 'x'


/*
 * The player-controlled criminal
 */
class Player : public Criminal {

	public:
		// class constructor
		Player(World* world);
		// class destructor
		~Player();

		// Make the players globally accessible
		static Player* player1;
		static Player* player2;

		// Override the default move fn
		void move(void);

		// Add a score drawing routine to the normal draw fn
		void draw(void);

		// Use Criminal::radiate
		void radiate(void);

		// These two fns are called by main when a key press event is captured.
		static void keyDown(int key);
		static void keyUp(int key);

	protected:

      // These variables store the state of the keys
      bool mUp, mDown, mLeft, mRight;

      // Set all the keys to being off (not pressed).
      void clearKeys(void);

};
#endif // PERSON_DEFINED
#endif // PLAYER_H
