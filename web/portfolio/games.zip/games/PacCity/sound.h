/* File: sound.h

This is a quick wrapper for some functions from the FMOD sound library.
It is taken from the fmod sample 'simplest'. 
See www.fmod.org for more information.

*/
#include <stdio.h>
#include <stdlib.h>
#if defined(WIN32) || defined(_WIN64) || defined(__WATCOMC__)
    #include <windows.h>
    #include <conio.h>
#else
    #include "../../api/inc/wincompat.h"
#endif

#include <fmod/fmod.h>
#include <fmod/fmod_errors.h>    /* optional */

namespace sound {

   int initSound();
   int loadSong(char* fileName);
   void deleteSong();

}
