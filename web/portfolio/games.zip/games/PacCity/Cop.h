// File: Cop.h

#ifndef COP_H

class Cop;

#include "Person.h" // inheriting class's header file
#include "Criminal.h"
#ifdef PERSON_DEFINED
#define COP_H

/*
   Cops are a subclass of Person.
   They chase criminals.
*/
class Cop : public Person
{
	public:
		// class constructor
		Cop(World* world);
		// class destructor
		~Cop();

		// Override the default fns
      void move(void);
      // emit cop radiation as well as person radiation
		void radiate(void);

      // hide the default value
      static int sRange;

	protected:

      // How strongly are cops attracted to criminals?
      static const int CRIMINAL_ATTRACTION = 30;

      // How strongly do cops repel each other?
      // This helps the cops behave smarter by not all ganging together in one place
      // It also attracts them to loot, since that gives off negative cop aroma
      static const int COP_AVOIDANCE = 5;

};

#endif //PERSON_DEFINED
#endif // COP_H

