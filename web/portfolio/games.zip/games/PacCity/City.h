/* File: City.h

A class for describing a city.
Also used to store data from the radiation model.

*/

//using namespace std;

#ifndef CITY_H
#define CITY_H

class City;

#include <windows.h>
#include <gl/gl.h> // open gl headers needed for the drawing routine
#include <iostream>
#include <vector>
#include "Locn.h"
#include "Person.h"
#include "Cop.h"
#include "Criminal.h"
#include "Player.h"
#include "Loot.h"
#include "World.h"
#include "EventCollision.h"


class City {
   public:
      /*
      Create a new City which is width x height blocks.
      Optionally set the street width and block width in terms of people widths.
      */
      City(World* world, int width, int height, int streetWidth=4, int blockWidth=10);

      // Will delete all maps and people
      ~City();

      // Draw the city
      void draw(void);
      // Move the inhabitants
      void move(void);

      /*
         Check whether a location is valid for a person.
         i.e. does it go outside the city or into a block?
         Returns: true if ok, false otherwise
      */
      bool checkStreetLocn(Locn& locn);

      /* Check whether a location collides with other units.
         Setting generateCollisionEvents determines whether
         or not this call will fire off a collision event into the event list
         Returns: true if ok, false if there IS a collision
      */
      bool checkCollision(Person* person, bool generateEvents);

      /*
         Generate a random street location within the city, and assign it to
         person.
         person is also used in checking for (& preventing) collisions.
         NULL can beused instead. If NULL is used, collisions will not be checked for.
      */
      Locn* randomStreetLocn(Person* person);

      // The size of the city in grid squares
      int mGridWidth, mGridHeight;

      bool withinBounds(int gridX, int gridY);
      
      // TODO: These things could be protected, with controlled access
      /*
      These arrays store the radiation levels which will control unit behaviour.
      */
      int** mCitizenRadiation;
      int** mCriminalRadiation;
      int** mCopRadiation;
      int** mLootRadiation;
      /*
      Constants for specifying type of radiation
      */
      static const int PERSON = 1;
      static const int COP = 2;
      static const int CRIMINAL = 3;
      static const int LOOT = 4;

      /* Sets local to be an array of the radiation of type type, centered on (x,y)
      type should be PERSON, COP or CRIMINAL
      This gives copies of the radiation, which can then be edited freely.
      */
      void getRadiation(int local[3][3], int gx, int gy, int type);

      // Sets local to be an array of the city map, centered on (x,y)
      void getBlockMap(int local[3][3], int gridX, int gridY);

      // The maximum value of radiation that a square can have. Used to signify walls
      static const int City::MAX_RADIATION = 1000000;

      // Update the radiation maps. Called once per move.
      void radiate();

      // The width of one grid square in opengl drawing coordinates
      static float sGridSquareWidth;

      // Store the population
      vector<Person*> mPeople;
      vector<Criminal*> mCriminals;
      vector<Cop*> mCops;
      // There is only ever 1 loot object
      Loot* mLoot;

      // Is this square a block or a street?
      // Provides controlled access to blockMap
      bool isBlock(int gx, int gy);

   protected:

      //ASSUME: We only have one city, so this is not needed.
      City(const City& city);

      World* mWorld; // The world

      // The size of the city in blocks
      int mWidth, mHeight;

      // The size of an individual street or block on grid squares
      int mStreetWidth, mBlockWidth;

      // A map of the grid, with 0s for street, 1s for city-block
      // NOTE: This array is accessed [y][x]
      int** blockMap;

      /* Update a specific radiation map. Called by radiate.
         type determines which propagation function to use
         Returns: total radiation of the map
         */
      int City::radiate(int** map, int type, int decayType);

      // Types for radiate
      // This means that the radiation gradient will lead to the nearest emitter
      static const int SHORTEST_PATH = 1;
      // This means that the radiation strength will reflect the number of emitters nearby
      static const int ADDITIVE = 2;
      // This gives long ranged effects (which we would otherwise require high-precision numbers for)
      static const int LINEAR = 4;
      // This gives localised effects
      static const int EXPONENTIAL = 8;

      // Create a random map
      void makeCityMap();

      // Make a random wandering street
      void makeRandomStreet(int x, int y, int dx, int dy);

      // This map will hold the corner colours. Used by the drawing function when displaying radiation maps.
      float*** mCornerMap;

};

#endif /* CITY_H */
