
Pac-City Demo
-------------
    by Daniel Winterstein

Development time: < 1 week

To run: double click on 'PacCity.exe'    
Instructions are given within the demo.

Developed using Bloodshed's DEV-C++ IDE and MinGW's C++ compiler.
Uses Open Gl and GLUT (v3.7.6).
If you are going to compile this you may need to install these libraries. Open GL is normally standard, but GLUT (a utility library for open gl, providing cross-platform window and keyboard support) is not.

Compiled on a Windows XP pentium machine.

Documentation is largely in the headers.

All materials are copyright Daniel Winterstein, 2005, unless otherwise stated. All rights reserved. 
