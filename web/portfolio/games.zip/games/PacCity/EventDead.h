// File: EventDead.h

#ifndef EVENTDEAD_H
#define EVENTDEAD_H

class EventDead;

#include "event.h" // inheriting class's header file
#ifdef EVENT_DEFINED // protect against include loops
/*
 * Event created when the player collides with a civilian.
   This is fatal, for no apparent reason.
 */
class EventDead : public Event
{
	public:
		// class constructor
		EventDead(World* world, Criminal* criminal, Person* person);
		// class destructor
		~EventDead();

	protected:
      static vector< vector<string*>* > sDialogues;		
};

#endif // EVENT_DEFINED
#endif // EVENTDEAD_H
