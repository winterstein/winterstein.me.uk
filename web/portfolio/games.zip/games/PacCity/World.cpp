/* File: World.cpp
*/
#include "World.h"

// Initialise Static Variables
World* World::singleton = NULL;
#ifdef DEBUG
ofstream* World::fileOut = NULL;
#endif

World::World(int players) {
   mPLAYERS = players;
#ifdef DEBUG
   // Set up the log
   // Todo: move this code to its own place
   if (!fileOut) {
      // Pipe cout into a file
      fileOut = new ofstream;
      fileOut->open("cout.txt");
      if (fileOut) {
         // Extract the buffer from just opened file.
         streambuf * fobuf = fileOut->rdbuf();
         // Redirect cout output to the opened file.
         cout.rdbuf(fobuf);
         // Demonstrate redirection.
         cout << "This verbage was put onto cout.\n";
      } else {
         cout << "Can't open output file cout.txt\n";
      }
   }
#endif // DEBUG

   #ifdef DEBUG
   *World::fileOut << "   World::World(players="<< players<<")"<<endl;
   #endif

   if (singleton) {
      throw "Error: attempt to create multiple worlds";
   } else {
      singleton = this;
   }

   // Create the city
   mCity = new City(this,4,4,1,8);

   // Now set the size for people
   Person::radius = Locn::sGridSquareWidth * 0.4;

   Person* dummy; // the new people will be stored in city
   // TODO: I should refactor World and City. 
   // If people are being stored in city, it should create/destroy them too.

   // And make some people (these are stored inside mCity)
   for(int i=0; i<PLEBS; i++) {
      dummy = new Person(this);
   }
   // Some criminals
   for(int i=0; i<CRIMINALS - mPLAYERS; i++) {
      dummy = new Criminal(this);
   }
   Player::player1 = new Player(this);
   if (mPLAYERS==2) Player::player2 = new Player(this);
   else Player::player2 = NULL;

   // Some loot
   dummy = new Loot(this);

   // Now some cops
   for(int i=0; i<COPS; i++) {
      dummy = new Cop(this);
   }
   // Start the clock
   gameStartTime = clock();
   // And we're off
   EventStart* start = new EventStart(this);
   setDirty();
}

World::~World(void) {
   #ifdef DEBUG
   // Shutdown the cout file
   *fileOut << "destroying the world\n";
   #endif // DEBUG
   mCurrentEvents.clear();
   delete mCity;
}

void World::draw(void) {
   #ifdef DEBUG
   *World::fileOut << "#---------- DRAW -------------#" << endl;
   #endif // DEBUG
   // Draw city (& people)
   mCity->draw();
   // Draw events
   for(int i=0; i<mCurrentEvents.size(); i++) {
      mCurrentEvents[i]->draw();
   }
   mDirty = false;
}

void World::move(void) {
   #ifdef DEBUG
   *World::fileOut << "#---------- NEW MOVE -------------#" << endl;
   #endif // DEBUG
   mCity->move();
   #ifdef DEBUG
   *World::fileOut << "#---------- RADIATE -------------#" << endl;
   #endif // DEBUG
   // Move the radiation outwards - this loop helps keep the radiation maps up-to-date
   for(int i=0; i<5; i++) {
      mCity->radiate();
   }
   #ifdef DEBUG
   *World::fileOut << "#---------- EVENTS -------------#" << endl;
   #endif // DEBUG
   // Let the events move along
   for(int i=0; i<mCurrentEvents.size(); i++) {
      mCurrentEvents[i]->move();
   }
}

bool World::isDirty(void) { return mDirty; }

void World::setDirty(void) { mDirty=true; }

float World::getTime() {
   return (1.0*clock() - gameStartTime) / CLK_TCK;
}
