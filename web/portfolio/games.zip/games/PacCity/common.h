/* File: common.h

   Contains some global definitions.
   Should be included in all files.

*/

#ifndef COMMON_H
#define COMMON_H



#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <iostream>
#include <fstream>

//#define DEBUG true

// Some simple debugging tools - replacing cout, which doesn't really work in Windows
#ifdef DEBUG
  #define LOUT(msg) *World::fileOut << "    "<<msg<<endl
  #define SOUT(msg) *World::fileOut << " "<<msg
  #define TRACE(msg) *World::fileOut << "    "<<typeid(*this).name()<<": "<<msg<<endl
#else // DEBUG
  #define LOUT(msg) ;
  #define SOUT(msg) ;
  #define TRACE(msg) ;
#endif // DEBUG

#define FULLSCREEN true

#ifndef NULL
#define NULL 0
#endif

const float PI = 3.141592f;
const float ROOT_TWO = 1.4142;

#endif // COMMON_H

