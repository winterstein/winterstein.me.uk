// File: EVentCapture.h

#ifndef EVENTCAPTURE_H
#define EVENTCAPTURE_H

#include "event.h" // inheriting class's header file
#include "EventRelease.h"

#ifndef EVENT_DEFINED
   class EventCapture;
#else //EVENT_DEFINED

/*
 * Event that occurs when a cop overlaps with a criminal.
 */
class EventCapture : public Event
{
	public:
		// class constructor
		EventCapture(World* world, Cop* cop, Criminal* thief);
		// class destructor
		~EventCapture();

	protected:
      static vector< vector<string*>* > sDialogues;

};

#endif //EVENT_DEFINED
#endif // EVENTCAPTURE_H
