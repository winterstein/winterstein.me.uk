/* File: Person.cpp
*/
#include "Person.h"

// Static Variables
float Person::radius = 0.1f;
int Person::sRange = 100;
const int Person::DRIVE = 4;
#ifdef DEBUG
int Person::maxRad = 0;
#endif


Person::Person(World* world) {
   TRACE("constructing new Person()");
   // initialise basics
   mWorld = world;
   mCity = mWorld->mCity;
   mPosn = NULL;
   // Register person
   mCity->mPeople.push_back(this);
   // Place them
   mCity->randomStreetLocn(this);
   // Give them some direction in life
   if (rand()%2) {
      mdx = -1 + 2*(rand() % 2);
      mdy = 0;
   } else {
      mdx = 0;
      mdy = -1 + 2*(rand() % 2);
   }
   targetdx = mdx;      targetdy = mdy;
   lastChangeDirection = world->getTime();
   mldx = mdx;     mldy = mdy;
   // colour and life
   mColour[0] = 0.3f + (rand() % 10)*0.01;
   mColour[1] = 0.5f + (rand() % 10)*0.01;
   mColour[2] = 0.3f + (rand() % 10)*0.01;
   // alive & visible
   mAlive = true; mVisible = true;
   mSpeed = City::sGridSquareWidth / 5;
   // citizens: not very agile
   // Todo: link this to frames-per-second
   mAGILITY = 0.02;   
   // nothing to say yet
   mStatement = NULL;
   // but can move
   mMove = true;
}

Person::Person() {
   // should not happen
   LOUT("ERROR: default constructor called on person (this is not allowed).");
   throw "ERROR: default constructor called on person.";
}

Person::Person(const Person& old) {
   // should not happen
   LOUT("ERROR: copy called on person!");
   throw "ERROR: copy called on person!";
}

Person::~Person(void) {
   #ifdef DEBUG
   *World::fileOut << "   person gone" << endl;
   #endif //DEBUG
   if (mPosn) {
      delete mPosn;
      mPosn = NULL;
   }
   if (mStatement) {
      delete mStatement;
      mStatement = NULL;
   }
}

/*
   Default movement: do nothing
*/
void Person::move(void) {
   if (!mMove) return;
   LOUT("person moving");
   changeDirection();

   int gx = mPosn->getGridX();
   int gy = mPosn->getGridY();

   // Get the local radiation maps
   int localPersonRadiation[3][3];
   int localCopRadiation[3][3];
   int localCriminalRadiation[3][3];
   mCity->getRadiation(localPersonRadiation,gx,gy,City::PERSON);
   mCity->getRadiation(localCopRadiation,gx,gy,City::COP);
   mCity->getRadiation(localCriminalRadiation,gx,gy,City::CRIMINAL);

   // Combine the maps
   int localRadiation[3][3];
   for(int i=0; i<3; i++) {
      for(int j=0; j<3; j++) {
         localRadiation[i][j] = (int) localPersonRadiation[i][j]
                                       + (abs(i-1-targetdy)+abs(j-1-targetdx))*DRIVE
                                       + 2*localCriminalRadiation[i][j]
                                       + 8*localCopRadiation[i][j];
      }
   }

   radiationMove(localRadiation);
   tryMove();
   LOUT("person moved\n");
   return;
}

void Person::changeDirection() {
   // Too soon to change?
//   if (mWorld->getTime() - lastChangeDirection < 1) return;
//   lastChangeDirection = mWorld->getTime();
   int gx, gy;
   gy = mPosn->getGridY();     gx = mPosn->getGridX();
   // Stick with same direction?
   // We change (a) randomly or (b) 'cos at a dead end
   if ((rand() % 16) != 1 && mCity->withinBounds(gx+targetdx,gy+targetdy)
        && !mCity->isBlock(gx+targetdx,gy+targetdy)) return;
   LOUT("Change direction!");
   int ndx,ndy;
   if (targetdx || targetdy) {
      if ((rand() % 4)==1) { // turn round
         ndx = -targetdx; ndy = -targetdy;
      } else { // turn sideways
         int pm = -1 + 2*(rand() % 2);
         ndx = targetdy*pm;
         ndy = targetdx*pm;
      }
   } else {
      if (rand()%2) {
         ndx = -1 + 2*(rand() % 2);
         ndy = 0;
      } else {
         ndx = 0;
         ndy = -1 + 2*(rand() % 2);
      }
   }
   gy = gy + ndy*3;
   gx = mPosn->getGridX() + ndx*3;
   if (!mCity->withinBounds(gx,gy)) return;
   if (mCity->isBlock(gx,gy)) return;
   #ifdef DEBUG
   *World::fileOut << "Changing direction from "<<targetdx<<targetdy<<" to "<<ndx<<ndy<<endl;
   #endif // DEBUG
   targetdx = ndx;
   targetdy = ndy;
}

void Person::radiationMove(int localRadiation[3][3]) {
   // gridX, gridY are used to check the city map for walls
   int gridX = mPosn->getGridX();
   int gridY = mPosn->getGridY();
   // Find the neighbouring square with the lowest radiation
   int minRad = City::MAX_RADIATION;
   int minY=-1, minX;

   // get the block map
   int localBlockMap[3][3];
   mCity->getBlockMap(localBlockMap,gridX,gridY);

   // First the cross-piece
   for(int i=0; i<3; i++) {
      for(int j=0; j<3; j++) {
         if (abs(i-1)==abs(j-1) && i) continue; // corner square
         if (localBlockMap[i][j]) continue;
         if (localRadiation[i][j] < minRad) {
            minRad = localRadiation[i][j];
            minY = i; minX = j;
         }
      }
   }
   // Then the corners (which are thus less likely to be selected)
   for(int i=0; i<3; i+=2) {
      for(int j=0; j<3; j+=2) {
         if (localBlockMap[i][j]) continue;
         if (localRadiation[i][j] < minRad) {
            minRad = localRadiation[i][j];
            minY = i; minX = j;
         }
      }
   }
   // Now change direction
   if (minY==-1 // Trapped!
       || minRad == localRadiation[1][1] // prefer standing still if equal
       ) {
      mdx=0; mdy=0;
   } else {
      Locn* target = Locn::getGridSquareCentre(gridX + minX-1, gridY + minY-1);
      float newdx = target->getX() - mPosn->getX();
      float newdy = target->getY() - mPosn->getY();
      // Normalise the vector, if possible
      double norm = sqrt(newdx*newdx + newdy*newdy);
      if (norm>0) {
         newdx = newdx / norm;
         newdy = newdy / norm;
      }
      // Limit rate of change to give smoother motion
      if (abs(newdx - mdx) > mAGILITY) {
          if (newdx > mdx) newdx = mdx + mAGILITY; else newdx = mdx - mAGILITY;
          if (newdy > mdy) newdy = mdy + mAGILITY; else newdy = mdy - mAGILITY;
      }
      mdx = newdx; mdy = newdy;
      delete target;
      #ifdef DEBUG
      *World::fileOut << " Direction: " << mdx << ", " << mdy << endl;
      #endif //DEBUG
   }
}

bool Person::tryMove() {
      #ifdef DEBUG
      *World::fileOut << " Try move: Direction: " << mdx << ", " << mdy << endl;
      #endif //DEBUG
   // Copy the direction vector so we can change it if necc.
   double dx = mdx, dy = mdy;
   if (dx==0 && dy==0) return false;
   // Store direction for drawing when still
   mldx = mdx; mldy = mdy;

   // Store the current location
   Locn* oldLocn = new Locn(mPosn->getX(),mPosn->getY());
   bool moved = false;
   // Try to move in the specified direction
   // HACK: If we hit something, we will try taking a smaller step
   //       - but just by halving a few times, rather than calculation
   for(int i=0; i<3; i++) {
      mPosn->setX(mPosn->getX() + dx*mSpeed);
      if (!mCity->checkStreetLocn(*mPosn)) {
         mPosn->setX(oldLocn->getX()); // bad x move - revert to previous x
         dx *= 0.5;
      } else {
         moved = true;
         break;
      }
   }
   for(int i=0; i<3; i++) {
   mPosn->setY(mPosn->getY() + dy*mSpeed);
      if (!mCity->checkStreetLocn(*mPosn)) {
         mPosn->setY(oldLocn->getY()); // bad y move - revert to previous y
         dy *= 0.5;
      } else {
         moved = true;
         break;
      }
   }
   // Check for unit collisions
   #ifdef DEBUG
   *World::fileOut << "   Testing for collisions" << endl;
   #endif // DEBUG
   if (moved && !mCity->checkCollision(this, true)) {
      moved = false;
       // bad move - revert to previous x, y
      mPosn->setX(oldLocn->getX());
      mPosn->setY(oldLocn->getY());
      LOUT("tryMOve(): Collision!");
   }
   LOUT("tryMove() tests done");
   if (moved) World::singleton->setDirty();
   delete oldLocn;
   return moved;
}

void Person::radiate(void) {
   if (!mVisible || !mPosn) return; // inivisible people don't affect the radiation maps
   int gy = mPosn->getGridY(), gx = mPosn->getGridX();
   LOUT(mCity->mCitizenRadiation[gy][gx]);
   mCity->mCitizenRadiation[gy][gx] += Person::sRange;

   // TODO: Block other radiation types?
   // This would discourage paths that pass through traffic congested areas
/*   if (mCity->mCriminalRadiation[mPosn->getGridY()][mPosn->getGridX()] > 0)
      mCity->mCriminalRadiation[mPosn->getGridY()][mPosn->getGridX()] -= BLOCKING_EFFECT;
   if (mCity->mCopRadiation[mPosn->getGridY()][mPosn->getGridX()] > 0)
      mCity->mCopRadiation[mPosn->getGridY()][mPosn->getGridX()] -= BLOCKING_EFFECT;
   */

   #ifdef DEBUG
   int rad = mCity->mCitizenRadiation[mPosn->getGridY()][mPosn->getGridX()];
   if (rad > maxRad) {
       maxRad = rad;
       SOUT("New Maximum Radiation:"); LOUT(rad);
   }
   if (mCity-> mCitizenRadiation[mPosn->getGridY()][mPosn->getGridX()] >= City::MAX_RADIATION) {
      LOUT("ERROR: Max radiation level exceeded!");
      throw "Max radiation level exceeded!";
   }
   #endif // DEBUG
}

/*
   Draw circular people
*/
void Person::draw(void) {
   TRACE("draw");
   glBegin(GL_POLYGON);
   float shade; // this will scale the colours to create a simple shading effect
   glColor3f(mColour[0], mColour[1], mColour[2]);
   glVertex2f(mPosn->getX(), mPosn->getY());
   // direction
   float dx = mdx, dy = mdy;
   if (mdx==0 && mdy==0) { dx = mldx; dy = mldy; }
   float length = sqrt(dx*dx + dy*dy);
   float theta = acos(dx/length); //angle
   if (dy<0) theta = -theta; // correct for cos's symmetry
   float ii = theta+PI/6;
   for (float i=ii; i < theta + 2*PI - PI/6; i+= PI/8.0f) {
      shade = 0.6 + 0.4*cos(i-PI/4.0f); // stick the light side to the top-right
      glColor3f(mColour[0]*shade, mColour[1]*shade, mColour[2]*shade);
      glVertex2f(mPosn->getX() + cos(i)*Person::radius,
                 mPosn->getY() + sin(i)*Person::radius);
   }

   glColor3f(mColour[0], mColour[1], mColour[2]);
   glVertex2f(mPosn->getX(), mPosn->getY());
   glEnd();
   // Draw text - if any - to the right of the character
   if (mStatement) {
      glColor3f(mColour[0], mColour[1], mColour[2]);
      renderBitmapString(mPosn->getX()+0.05,
                         mPosn->getY(), 0, mStatement);
   }
}

void Person::talk(char* msg) {
   #ifdef DEBUG
   *World::fileOut << "Talking:" << endl;
   *World::fileOut << msg << endl;
   #endif // DEBUG
   if (mStatement) delete mStatement;
   mStatement = new char[strlen(msg)+1];
   strcpy(mStatement,msg);
   SOUT("Talk:");
   LOUT(mStatement);
}

void Person::silence() {
   if (!mStatement) return;
   delete mStatement;
   mStatement = NULL; // The next World::draw() call will wipe the text off
}

bool Person::overlap(Person& bob) {
   Locn* bobPosn = bob.mPosn;
   if (!mVisible || !bob.mVisible || !mPosn || !bobPosn) return false;
   if (mPosn->dist(*bobPosn) < 2*radius) return true;
   return false;
}
