/* File: World.h

A namespace containing the game world variables.

*/

#ifndef WORLD_H
#define WORLD_H

#include <fstream>

class World; // Forward declare World for reference in includes

#include "common.h"
#include "Person.h"
#include "Cop.h"
#include "Criminal.h"
#include "Player.h"
#include "Loot.h"
#include "City.h"
#include "Event.h"
#include "EventStart.h"


class World {
   public:
      #ifdef DEBUG
      // This will be used instead of cout (since cout doesn't work in a Windows GUI).
      static ofstream* fileOut;
      #endif

      /* ASSUME: We only have one world - which we make available through singleton.
      This will be enforced in the constructors.
      */
      static World* singleton;

      // Create the world!
      World(int players);

      // Will delete city and events
      ~World(); // The end of the world!

      // The city in which everything happens
      City* mCity;

      /* fn to draw everything.
         ASSUME: open gl has already been set up.
         ASSUME: GL command flushing and windows buffer swapping will be done in a parent function.
         ASSUME: sets mDirty to false when finished.
      */
      void draw(void);

      /* fn to move everything.
         ASSUME: The city doesn't move, only the people.
      */
      void move(void);

      bool isDirty();

      /* Mark that something has changed, and redrawing is called for.
         ASSUME: This will be called by all functions that change any world variable
         Note that only World::draw() should set mDirty to be false.
      */
      void setDirty();

      // Returns the game time in seconds
      float getTime();

   protected:
      // Whether the world has changed, and hence should be redrawn
      bool mDirty;

      // This copy constructor should never be called
      World(const World& old);

      static const int COPS = 1;
      static const int PLEBS = 10;
      static const int CRIMINALS = 2;
      int mPLAYERS;

      // start of the game in clock ticks
      long int gameStartTime;

      // Recent events. Maintained by Event(), ~Event()
      vector<Event*> mCurrentEvents;

      // Allow events to access mCurrentEvents
      friend class Event;
};

#endif /* WORLD_H */
