/*===============================================================================================
 SIMPLEST.EXE
 Copyright (c), Firelight Technologies Pty, Ltd, 1999,2000.

 This is the simplest way to play a song through FMOD.  It is basically Init, Load, Play!
===============================================================================================*/

#include "sound.h"

FMUSIC_MODULE *mod = NULL;

    /*
        INITIALIZE
    */
int sound::initSound()
{

    if (FSOUND_GetVersion() < FMOD_VERSION)
    {
        printf("Error : You are using the wrong DLL version!  You should be using FMOD %.02f\n", FMOD_VERSION);
        return 0;
    }
    
    if (!FSOUND_Init(32000, 64, 0))
    {
        printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
        return 0;
    }
    return 1;
}

    /*
        LOAD SONG
    */
  
int sound::loadSong(char * fileName) {
    mod = FMUSIC_LoadSong(fileName);
    if (!mod)
    {
        printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
        return 0;
    }
    FMUSIC_PlaySong(mod);   
    return 1;
}

    /*
        FREE SONG AND SHUT DOWN
    */
void sound::deleteSong() {
    FMUSIC_FreeSong(mod);
    FSOUND_Close();
}
