// File: Criminal.cpp

#include "Criminal.h" // class's header file

// Initialise static variables
int Criminal::sRange = 1000;

// class constructor
Criminal::Criminal(World* world) : Person::Person(world) {
   mColour[0] = 1.0f;   mColour[1] = 0.0f;   mColour[2] = 0.0f;
   mCity->mCriminals.push_back(this);
   // Criminals move faster than anyone else (otherwise they'd be stuffed).
   mSpeed *= CRIMINAL_SPEED;
   // A bit more agile than a citizen 
   mAGILITY = 0.1;   
   mScore = 0;
}

// class destructor
Criminal::~Criminal()
{
	// insert your code here
}

void Criminal::radiate(void) {
   if (!mVisible || !mPosn) return;
   // Criminals are people too
   Person::radiate();
   if (!mMove) return; // Either being arrested or released - don't really want more cops arriving
   mCity->mCriminalRadiation[mPosn->getGridY()][mPosn->getGridX()] = Criminal::sRange;
   #ifdef DEBUG
   if (mCity-> mCriminalRadiation[mPosn->getGridY()][mPosn->getGridX()] >= City::MAX_RADIATION)
      LOUT("ERROR: Max radiation level exceeded!");
   #endif // DEBUG
}

void Criminal::move(void) {
   if (!mMove) return;
   #ifdef DEBUG
   *World::fileOut << " Criminal move" << endl;
   #endif //DEBUG
   changeDirection();

   // Get the local radiation maps
   int localPersonRadiation[3][3];
   int localCopRadiation[3][3];
   int localLootRadiation[3][3];
   int gx = mPosn->getGridX();
   int gy = mPosn->getGridY();
   mCity->getRadiation(localPersonRadiation,gx,gy,City::PERSON);
   mCity->getRadiation(localCopRadiation,gx,gy,City::COP);
   mCity->getRadiation(localLootRadiation,gx,gy,City::LOOT);

   // Combine the maps
   int localRadiation[3][3];
   for(int i=0; i<3; i++) {
      for(int j=0; j<3; j++) {
         localRadiation[i][j] = localPersonRadiation[i][j]
                                 + 15 * localCopRadiation[i][j]
                                 - 3 * localLootRadiation[i][j]
                                 - (abs(i-1-targetdy)+abs(j-1-targetdx))*DRIVE;
      }
   }

   radiationMove(localRadiation);
   bool success = tryMove();

   #ifdef DEBUG
   *World::fileOut << " criminal moved: " << success << endl;
   #endif //DEBUG
}


