/* File: EventCapture.cpp
*/

#include "eventcapture.h" // class's header file

vector< vector<string*>* > EventCapture::sDialogues;

// class constructor
EventCapture::EventCapture(World* world, Cop* cop, Criminal* thief)
   : Event(world, cop, thief) {
   // Check: The player can be dead or already involved in some fatal event
   if (!thief->mAlive || !thief->mMove) return;
      // Initialise if necc.
   if (sDialogues.size()==0) {
      cacheOneLiner(sDialogues,"A:Gotcha");
      cacheOneLiner(sDialogues,"A:Give up PacRobber");
      cacheOneLiner(sDialogues,"B:Is it 'cos I is black?");
   }
   #ifdef DEBUG
   *World::fileOut << "EVENT: Criminal caught" << endl;
   #endif // DEBUG
   // Freeze the actors
   cop->mMove = false;
   thief->mMove = false;
   // set dialogue
   setDialogue(sDialogues);
   mTimeLimit = 5;
}

// class destructor
EventCapture::~EventCapture() {
   mA->mMove = true;
   
   mB->mAlive = false;
   mB->mVisible = false;   
   if (typeid(*mB) == typeid(Player)) {
      LOUT("Game over for someone");
      delete mB->mPosn;
      mB->mPosn = NULL;
      return;
   } else {
      // Release the criminal
      EventRelease* release = new EventRelease(mWorld, mB);
   }
}


