/* File: main.cpp

   For details on the code structure, please see README.txt

   This file contains mostly open GL and GLUT  initialisation code.
   It is largely adapted from online tutorials.
*/

// Includes
using namespace std;
#include "common.h"
#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include "dangl.h"
#include "sound.h"
#include <iostream>
#include <fstream>
#include <ctime>
#include "Person.h"
#include "World.h"
#include "Player.h"


// The game world
World* world;

// The last move in clock ticks
long int lastMoveTime;

// Number of clock ticks per move - i.e. caps the no. moves per second
long int moveGap;

// Picture for title screen
GLuint intro_image = 0;

// This will start a new game
void startGame(int players);

void renderScene(void) {
   if (clock() - lastMoveTime > moveGap) {
      world->move();
//      if (world->isDirty()) { // NOTE: The world is *always* dirty
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      // Draw the world afresh
      world->draw();
      // Flush the buffer to force drawing of all objects thus far
	   glFlush();
      // Swap the buffers to display drawing
      glutSwapBuffers();
//      }      
      float fps = (1.0*CLK_TCK) / (clock()-lastMoveTime);
      SOUT("Fps:"); SOUT(fps);
      lastMoveTime = clock();
   }
}

/*
   Clean up and close down
*/
void intro_exitGame(void) {
   glutSetKeyRepeat(GLUT_KEY_REPEAT_DEFAULT); // restore normal key behaviour
   if (intro_image) glDeleteTextures(1,&intro_image);
	// end sound system
   sound::deleteSong();
   exit(0); // This gets us out of the Glut loop
}

void intro_processNormalKeys(unsigned char key, int x, int y) {
   switch (key) {
      case 27:
         // Escape pressed - quit game
         intro_exitGame();
         break;
      case '1':
         startGame(1); break;
      case '2':
         startGame(2); break;
      default: break; // do nothing
   }
}

void intro_renderScene(void) {
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
/*   renderBitmapString(0,-0.2,0,"Pac-City");
   renderBitmapString(0,0.2,0,"[1] Start One Player Game");
   renderBitmapString(0,0.4,0,"[2] Start Two Player Game");
   renderBitmapString(0,0.6,0,"CONTROLS...");
*/
//Load the texture
glBindTexture(GL_TEXTURE_2D, intro_image);
glColor3f(1,1,1);
glBegin(GL_POLYGON);
     //Top-left vertex (corner)
     glTexCoord2f(0,1);
     glVertex3f(-1, -1, 0.0f);

     //Bottom-left vertex (corner)
     glTexCoord2f(1,1);
     glVertex3f(1, -1, 0.0f);

     //Bottom-right vertex (corner)
     glTexCoord2f(1,0);
     glVertex3f(1, 1, 0.0f);

     //Top-right vertex (corner)
     glTexCoord2f(0,0);
     glVertex3f(-1, 1, 0.0f);
glEnd();


   // Flush the buffer to force drawing of all objects thus far
   glFlush();
   // Swap the buffers to display drawing
   glutSwapBuffers();

}

/*



*/

/*
   Register the GLUT event handlers for the INTRO
*/
void intro_register_glut_handlers(void) {
   glutKeyboardFunc(intro_processNormalKeys);
   glutDisplayFunc(intro_renderScene);
   glutIdleFunc(intro_renderScene);
}


void initIntro(void) {
   //Enable texturing
   glEnable(GL_TEXTURE_2D);
   if (!intro_image) intro_image = LoadTexture("data/paccity.tga");
   intro_register_glut_handlers();
}


/*
   Exit a game and enter the intro screen
*/
void exitGame() {
   LOUT("Exiting game");
   delete world;
   World::singleton = NULL;
   initIntro();
}

// Keyboard event handlers

void processNormalKeys(unsigned char key, int x, int y) {
   if (key==27) {
      // Escape pressed - quit game
      exitGame();
   }
   Player::keyDown(key);
}

void processNormalKeysUp(unsigned char key, int x, int y) {
   Player::keyUp(key);
}

/*
   Pass key down events on to the Player class
*/
void processSpecialKeys(int key, int x, int y) {
   Player::keyDown(key);
}
/*
   Pass key up events on to the Player class
*/
void processSpecialKeysUp(int key, int x, int y) {
   Player::keyUp(key);
}

/*
   Initialise Open GL, GLUT and the intro screen
   TODO: handle error messages gracefully
*/
void main_init(int argc, char **argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
#ifdef FULLSCREEN
	glutGameModeString("800x600:32");
	// enter full screen
	if (glutGameModeGet(GLUT_GAME_MODE_POSSIBLE))
		glutEnterGameMode();
	else { // fallback to window mode
	  cout << "The requested graphics mode is not available" << endl;
     glutInitWindowPosition(100,100);
	  glutInitWindowSize(400,400);
	  glutCreateWindow("Dan's Demo");
	}
#else // FULLSCREEN
   glutInitWindowPosition(100,100);
	glutInitWindowSize(400,400);
	glutCreateWindow("Dan's Demo");
#endif // FULLSCREEN
   glutIgnoreKeyRepeat(1);

   // Set the clear color to black
	glClearColor(0.0, 0.0, 0.0, 0.0);

   // Initialise the random number generator
   srand(time(0));

  // Set max moves per second
  moveGap = CLK_TCK / 50;

   // Lets have some music
   sound::initSound();
   sound::loadSong("data/invtro94.s3m");

}

/*
   Register the GLUT event handlers for the game
*/
void register_game_handlers() {
   glutKeyboardFunc(processNormalKeys);
   glutKeyboardUpFunc(processNormalKeysUp);
	glutSpecialFunc(processSpecialKeys);
   glutSpecialUpFunc(processSpecialKeysUp);
   glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);
}


/*
   Exit the intro screen and start a game.
*/
void startGame(int players) {
   //Disable texturing
   glDisable(GL_TEXTURE_2D);
   // Create the game world
   world = new World(players);
   LOUT("Start!");
   // store the time when we last updated everything's position
   lastMoveTime = clock ();
   // Switch event routing to the game routines
   register_game_handlers();
}


int main(int argc, char **argv) {
   // Initialise stuff
	main_init(argc, argv);
   // Set up the intro
   initIntro();
   // GO!
	glutMainLoop(); // This never exits - see exitGame
}
