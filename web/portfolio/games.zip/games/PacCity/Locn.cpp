/* File: Locn.cpp
   A lightweight class for describing locations.
 */

#include "Locn.h"

// Initialise static variables
float Locn::sGridSquareWidth = 1.0f;

Locn::Locn() {
   setX(0); setY(0);
}

Locn::Locn(float drawX, float drawY) {
   setX(drawX);
   setY(drawY);
}

Locn::Locn(const Locn& locn) {
   mGridX = locn.mGridX;   mGridY = locn.mGridY;
   mDrawX = locn.mDrawX;   mDrawY = locn.mDrawY;
}

Locn::~Locn() {
   // nothing to do
}

void Locn::setGridSquareWidth(float width) {
   sGridSquareWidth = width;
}

inline void Locn::setGridX() {
   mGridX = (int) floor( (1 + mDrawX) / Locn::sGridSquareWidth );
}
inline void Locn::setGridY() {
   mGridY = (int) floor( (1 + mDrawY) / Locn::sGridSquareWidth );
}

float Locn::getX() {
   return mDrawX;
}
float Locn::getY() {
   return mDrawY;
}

int Locn::getGridX() {
   return mGridX;
}
int Locn::getGridY() {
   return mGridY;
}

void Locn::setX(float x) {
   mDrawX = x;
   setGridX();
}

void Locn::setY(float y) {
   mDrawY = y;
   setGridY();
}

double Locn::dist(Locn& b) {
   // Euclidean metric
   float x = mDrawX - b.mDrawX;
   float y = mDrawY - b.mDrawY;
   #ifdef DEBUG
   if (sqrt(x*x + y*y) > 5)
      *World::fileOut << "ERROR: dist() is too big"<<endl;
   #endif
   return sqrt(x*x + y*y);
}

Locn* Locn::getGridSquareCentre() {
   float cx, cy;
   cx = (mGridX+0.5)*sGridSquareWidth -1;
   cy = (mGridY+0.5)*sGridSquareWidth -1;
   Locn* gsc = new Locn(cx,cy);
   return gsc;
}

Locn* Locn::getGridSquareCentre(int gridX, int gridY) {
   float cx, cy;
   cx = (gridX+0.5)*sGridSquareWidth -1;
   cy = (gridY+0.5)*sGridSquareWidth -1;
   Locn* gsc = new Locn(cx,cy);
   return gsc;
}

