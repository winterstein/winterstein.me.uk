/* File: Person.h

Contains the basic code common to all types of people.

*/

#ifndef PERSON_H
#define PERSON_H

using namespace std;

class Person; // forward declare class

#include "common.h"
#include <windows.h> // needed by open gl headers
#include <gl/gl.h> // open gl headers needed for the drawing routine
#include "dangl.h"
#include <cmath>
#include "Locn.h"
#include "City.h"
#include "World.h"


class Person {
   public:
      Person(World* world);
      // Protect sub-class destructors
      virtual ~Person();

      /*
      Move the person. This includes thinking about where they want to go.
      */
      virtual void move(void);

      // Can this unit move?
      bool mMove;

      // Draw the person. ASSUME: See World::draw()
      virtual void draw(void);

      // The character speaks. Draw the text onscreen at their location.
      // NOTE: The actual drawing is done by draw
      // NOTE: This is a crude function; it doesn't protect against text running off-screen.
      virtual void talk(char* msg);
      // Remove the text set by talk()
      void silence();

		// Emit radiation (adjusting the radiation maps held by the city).
      // Called by the World once per move.
		virtual void radiate(void);

      // Test whether two people overlap
      // Note: Invisible people cannot overlap
      bool overlap(Person& bob);


      // Is the person alive? If not, no need to move them.
      bool mAlive;

      // Is the person visible? If not, no need to draw them.
      bool mVisible;

      // The size of a person
      static float radius;

      // Controls the strength of radiation emitted, and hence the range it can be detected at
      static int sRange;
      
      #ifdef DEBUG
      static int maxRad; // track the maximum radiation level reached
      #endif
      // This person's location
      Locn* mPosn;
      void setColour(float r, float g, float b) {
         mColour[0] = r; mColour[1] = g; mColour[2] = b;
      }

   protected:
      
      // This limits a unit's ability to turn
      float mAGILITY;

      World* mWorld;

      City* mCity;

      // The amount a person can move each time move() is called.
      float mSpeed;

      // Colour to draw person in.
      float mColour[3];

      // Direction to move in: a unit vector, or 0
      double mdx, mdy;

      // Last direction moved in - used for drawing if mdx=mdy=0
      double mldx, mldy;

      // Target direction to move in
      double targetdx, targetdy;

      // Pick a random new direction
      // - Normal people just do a random walk through the maze
      void changeDirection();

      // Don't change direction unless the radiation difference is this or better
      const static float THRESHOLD = 0.5f;

      // Calculate a move for this unit according to the local radiation levels
      // Adjusts mdx, mdy
      void radiationMove(int localRadiation[3][3]);

      // Try to move the unit in the specified direction
      bool tryMove();

      // Set by talk()
      char* mStatement;

      // How much does the unit want to go in their preferred direction?
      static const int DRIVE;

      // When did this unit last change it's goal
      float lastChangeDirection;

   private:
      // Lock these away
      Person(const Person& old);
      Person();

};

#define PERSON_DEFINED true
#endif // PERSON_H

